local noop = function () end
local texture = nil
local animation_path = nil

-- cursor.lua
local Cursor = {}

local function spawn_smoke(canguard)
  local field = canguard:get_field()
  local tile = canguard:get_tile(Direction.Left, 1)

  local artifact = Battle.Artifact.new(canguard:get_team())
  artifact:set_layer(-1)
  artifact:set_position(42, -65)
  artifact:set_texture(texture, true)

  local anim = artifact:get_animation()
  anim:load(animation_path)
  anim:set_state("SMOKE")
  anim:on_complete(function()
    artifact:remove()
  end)

  field:spawn(artifact, tile:x(), tile:y())
end

local function attack(canguard, cursor, target)
  -- set the cursor up for damage
  cursor.spell:set_hit_props(make_hit_props(
    canguard._attack,
    Hit.Flinch | Hit.Impact | Hit.Flash,
    Element.None,
    canguard:get_id(),
    drag(Direction.None, 0)
  ))

  local cursor_anim = cursor.spell:get_animation()
  cursor_anim:set_state("CURSOR_SHOOT")
  cursor_anim:set_playback(Playback.Once)

  local canguard_anim = canguard:get_animation()
  canguard_anim:set_state(canguard._shoot_state)
  canguard_anim:on_complete(function()
    cursor.spell:get_current_tile():attack_entities(cursor.spell)
    spawn_smoke(canguard)

    if not target then
      -- reached the end, delete the cursor
      cursor:remove()
      return
    end

    local canguard_tile = canguard:get_current_tile()
    local destination = target:get_current_tile()

    if destination:y() ~= canguard_tile:y() then
      cursor:remove()
      return
    end

    cursor.spell:teleport(destination, ActionOrder.Immediate)

    canguard_anim:set_state(canguard._idle_state)
    canguard_anim:on_complete(function()
      attack(canguard, cursor, target)
    end)
  end)
end

local function begin_attack_loop(canguard, cursor, target)
  -- stop the cursor from scanning for players
  cursor.spell.update_func = noop
  cursor.spell.attack_func = noop

  attack(canguard, cursor, target)
end

local function spawn_cursor(cursor, canguard, x, y)
  local spell = Battle.Spell.new(canguard:get_team())
  spell:set_texture(texture, true)
  spell:set_layer(-1)
  spell:set_hit_props(make_hit_props(
    0,
    Hit.None,
    Element.None,
    canguard:get_id(),
    drag(Direction.None, 0)
  ))

  local anim = spell:get_animation()
  anim:load(animation_path)
  anim:set_state("CURSOR")
  anim:set_playback(Playback.Once)

  local field = canguard:get_field()
  field:spawn(spell, x, y)

  local function move()
    local destination = spell:get_tile(Direction.Left, 1)
    spell:slide(
      destination,
      frames(canguard._frames_per_cursor_movement),
      frames(0),
      ActionOrder.Immediate,
      noop
    )
  end

  spell.update_func = function(action, time)
    spell:get_current_tile():attack_entities(spell)

    -- test if we need to move
    if spell:is_moving() then
      return
    end

    local tile = spell:get_current_tile()

    if tile:x() > 1 then
      move()
    else
      begin_attack_loop(canguard, cursor)
    end
  end

  spell.attack_func = function(_, character)
    begin_attack_loop(canguard, cursor, character)
  end

  spell.delete_func = noop

  spell.can_move_to_func = function(tile)
    return true
  end

  return spell
end

function Cursor:new(canguard, x, y)
  local cursor = {
    spell = nil,
    is_deleted = false,
  }

  setmetatable(cursor, self)
  self.__index = self

  cursor.spell = spawn_cursor(cursor, canguard, x, y)

  return cursor
end

function Cursor:remove()
  self.is_deleted = true
  self.spell:remove()
end

-- entry.lua

local target_update, idle_update

target_update = function(canguard, dt)
  if canguard._cursor.is_deleted then
    canguard.update_func = idle_update
  end
end

idle_update = function(canguard, dt)
  local target = canguard:get_target()
  local current_tile = canguard:get_current_tile()
  local y = current_tile:y()

  if not target then return end -- no target
  if y ~= target:get_current_tile():y() then return end -- not same row

  local x = current_tile:x()
  canguard._cursor = Cursor:new(canguard, x, y)
  canguard.update_func = target_update
end

function package_init(canguard)
  if not texture then
    texture = Engine.load_texture(_modpath.."canodumb_atlas.png")
    animation_path = _modpath.."canodumb.animation"
  end

  -- private variables
  canguard._frames_per_cursor_movement = 15
  canguard._cursor = nil
  canguard._idle_state = "IDLE_1"
  canguard._shoot_state = "SHOOT_1"
  canguard._attack = 10

  -- meta
  canguard:set_name("CanGuard")
  -- canguard:set_rank(Rank.EX)
  canguard:set_health(60)
  canguard:set_height(55)

  canguard:set_texture(texture, true)

  local anim = canguard:get_animation()
  anim:load(animation_path)
  anim:set_state(canguard._idle_state)
  anim:set_playback(Playback.Once)

  -- setup defense rules
  canguard.defense = Battle.DefenseVirusBody.new()

  -- setup event hanlders
  canguard.update_func = idle_update
  canguard.battle_start_func = noop
  canguard.battle_end_func = noop
  canguard.on_spawn_func = noop
  canguard.can_move_to_func = noop
  canguard.delete_func = noop
end
