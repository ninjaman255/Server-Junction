function package_requires_scripts()
  Engine.define_character("com.discord.Konstinople#7692.enemy.canguard", _modpath.."canguard")
end

function package_init(package)
  package:declare_package_id("com.discord.Konstinople#7692.canguard")
  package:set_name("CanGuard")
  package:set_description("Canodumbs with CanGuard AI")
  -- package:set_speed(999)
  -- package:set_attack(999)
  -- package:set_health(9999)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
  local field = mob:get_field()

  local tile = field:tile_at(4, 2)

  if not tile:is_walkable() then
    tile:set_state(tile_state.Normal)
  end

  local spawner = mob:create_spawner("com.discord.Konstinople#7692.enemy.canguard")
  spawner:spawn_at(5, 2) -- todo: rank 1
  spawner:spawn_at(6, 1) -- todo: rank 2
  spawner:spawn_at(6, 3) -- todo: rank 3
end
